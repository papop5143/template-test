function howareyou(mood = "Happy") {
	console.log(mood);
}
howareyou();
