// Function & Arrow Functions


console.log(("small" || "large"));

console.log(("large" || "small"));