var math1 = require("./math.1.js");
var math2 = require("./math.2.js");

// solution 1 : math1
console.log("1|", math1.add(1, 2));
console.log("1|", math1.substract(1, 2));
console.log("1|", math1.multiple(1, 2));

// solution 2 : math2
console.log("2|", math2.add(1, 2));
console.log("2|", math2.substract(1, 2));
console.log("2|", math2.multiple(1, 2));