const firstname = 'Robot'
const lastname = 'TrippleX'
const date = new Date();
const great = `Hello, ${firstname +  ' ' + lastname}, how are you ${date}?`
console.log(great);