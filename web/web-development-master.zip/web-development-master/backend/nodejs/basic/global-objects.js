console.log("__filename\t", __filename);
console.log("__dirname\t", __dirname);
// console.log("process.env\t", process.env);