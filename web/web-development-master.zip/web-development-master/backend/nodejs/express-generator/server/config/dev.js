module.exports = {
    mongoURI : "mongodb://localhost/shopper"
}