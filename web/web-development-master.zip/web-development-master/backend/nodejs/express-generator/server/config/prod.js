module.exports = {
    mongoURI : "mongodb://admin:12345678a@ds263460.mlab.com:63460/shopper-db"
}